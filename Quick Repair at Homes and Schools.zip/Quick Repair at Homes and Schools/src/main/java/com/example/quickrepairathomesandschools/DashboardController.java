package com.example.quickrepairathomesandschools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.Connection;


import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.Label;

public class DashboardController {

    @FXML
    private Label userNameLabel;

    @FXML
    private Label addressLabel;

    @FXML
    private TextArea problemTextArea;

    public void setUserData(String name, String address, String problem) {
        userNameLabel.setText("Name: " + name);
        addressLabel.setText("Address: " + address);
        problemTextArea.setText(problem);
    }

    @FXML
    public void onLogoutClick() {
        try {
            Main.showLoginForm(); // Navigate back to the login form
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
