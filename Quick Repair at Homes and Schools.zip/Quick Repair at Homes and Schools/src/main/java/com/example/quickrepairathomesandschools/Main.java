package com.example.quickrepairathomesandschools;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    private static Stage primaryStage;


    // Show the Dashboard
    public static void showDashboard(String username) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
            Parent root=loader.load();


            RequestServiceController controller = loader.getController();
            controller.setUserData(username);

            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showSignUpForm() {
    }

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        showLoginForm();  // Initially show the login form
    }

    // Show the Login form (Login.fxml)
    public static void showLoginForm() throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Scene scene = new Scene(loader.load(), 400, 300);
        primaryStage.setTitle("Quick Repair - Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Show the Request Service form (RequestService.fxml) without user data
    public static void showRequestServiceForm() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("RequestService.fxml"));
        Scene scene = new Scene(loader.load(), 400, 400);
        primaryStage.setTitle("Quick Repair - Request Service");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Overloaded: Show the Request Service form (RequestService.fxml) with user data
    public static void showRequestServiceForm(String username) throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("RequestService.fxml"));
        Scene scene = new Scene(loader.load(), 400, 400);
        RequestServiceController controller = loader.getController();
        controller.setUserData(username);  // Pass user data to the controller
        primaryStage.setTitle("Quick Repair - Request Service");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
