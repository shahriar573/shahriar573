// DB.java
package com.example.quickrepairathomesandschools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    private static final String URL = "jdbc:mysql://localhost:3306/a2?serverTimezone=UTC";  // Ensure proper timezone handling
    private static final String USER = "root";
    private static final String PASSWORD = "90123";

    // Initialize the database connection
    public static void initialize() {
        try {
            // Ensure the MySQL JDBC driver is loaded
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Database driver not found: " + e.getMessage());
        }
    }

    // Returns a connection to the database
    public static Connection getConnection() throws SQLException {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to the database.");
            return connection;
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database: " + e.getMessage());
            throw e;  // Rethrow the exception to be handled by the caller
        }
    }
}

