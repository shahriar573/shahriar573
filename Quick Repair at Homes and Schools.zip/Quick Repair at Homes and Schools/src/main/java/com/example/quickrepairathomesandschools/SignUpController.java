package com.example.quickrepairathomesandschools;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class SignUpController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    // Handling Sign Up form submission
    @FXML
    public void onSubmitSignUp() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Username and Password must be filled out.");
            return;
        }

        // Here you would typically add logic to save the new user in a database.
        // For now, we just show a success message.
        showAlert("Success", "Sign Up Successful!");

        // Clear fields after submission
        usernameField.clear();
        passwordField.clear();
    }

    // Navigate back to the Login form
    @FXML
    public void onBackToLoginClick() {
        try {
            Main.showLoginForm(); // Navigate to the login form
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Utility method to show alerts
    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
