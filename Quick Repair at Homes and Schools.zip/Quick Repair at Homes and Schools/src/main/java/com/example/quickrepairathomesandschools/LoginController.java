package com.example.quickrepairathomesandschools;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.example.quickrepairathomesandschools.Main.showRequestServiceForm;

public class LoginController {

    private static final Logger LOGGER = Logger.getLogger(LoginController.class.getName());

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private ChoiceBox<String> roleBox;

    public Label messageLabel;

    // Handling login form submission
    @FXML
    public void handleLoginSubmit(ActionEvent actionEvent) {
        // Log the source of the event
        Button sourceButton = (Button) actionEvent.getSource();
        LOGGER.info("Login button clicked: " + sourceButton.getText());

        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleBox.getValue();

        // Validate input fields
        if (username.isEmpty() || password.isEmpty() || role == null) {
            showAlert("Validation Error", "Please fill all the fields.");
            return;
        }

        String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
        try (Connection connection = DB.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, role);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Main.showDashboard(username); // Pass the username for continuity
                LOGGER.info("User " + username + " logged in successfully as " + role + ".");
            } else {
                LOGGER.warning("Invalid login attempt for user: " + username);
                showAlert("Login Failed", "Invalid credentials or role.");
            }
        } catch (SQLException | IOException e) {
            LOGGER.log(Level.SEVERE, "Error occurred during login", e);
            showAlert("Error", "An error occurred during login.");
        }

        // Reset the fields after login attempt
        usernameField.clear();
        passwordField.clear();
        roleBox.setValue(null);
    }

    // Show alerts to the user
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Additional method to handle login button click
    @FXML
    public void onLoginClick(ActionEvent actionEvent) {
        LOGGER.info("onLoginClick method invoked by: " + actionEvent.getSource());

        // Delegate to handleLoginSubmit for the actual processing
        handleLoginSubmit(actionEvent);

        // Log completion of the login click event
        LOGGER.info("Login processing completed.");
    }

    public void showRequestService(ActionEvent actionEvent) {
        // Log the source of the event
        Button sourceButton = (Button) actionEvent.getSource();
        LOGGER.info("Request Service button clicked: " + sourceButton.getText());

        try {
            // Navigate to the "Request Service" form or scene
            showRequestServiceForm();
            LOGGER.info("Navigated to Request Service form successfully.");
        } catch (Exception e) {
            // Log the error and show an alert to the user
            LOGGER.log(Level.SEVERE, "Failed to navigate to Request Service form", e);
            showAlert("Navigation Error", "An error occurred while trying to open the Request Service form.");
        }
    }
}
