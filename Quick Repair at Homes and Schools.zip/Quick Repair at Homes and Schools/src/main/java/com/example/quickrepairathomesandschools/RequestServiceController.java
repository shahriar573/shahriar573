package com.example.quickrepairathomesandschools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RequestServiceController {

    private static final Logger LOGGER = Logger.getLogger(RequestServiceController.class.getName());

    @FXML
    private TextArea problemField; // Correctly matched to FXML

    @FXML
    private TextField nameField;

    @FXML
    private TextField addressField;

    @FXML
    private Text actionTarget;

    @FXML
    private Label messageLabel;

    private String currentUser;

    @FXML
    public void initialize() {
        LOGGER.info("Initializing RequestServiceController.");
        if (problemField == null) {
            LOGGER.severe("problemField is null! Check FXML binding.");
        }
    }

    public void setUserData(String username) {
        this.currentUser = username;
        LOGGER.info("User data set for Request Service: " + username);
    }

    @FXML
    public void onSubmitRequestClick() {
        String name = nameField.getText().trim();
        String address = addressField.getText().trim();
        String problem = problemField.getText().trim();

        // Validate input fields
        if (name.isEmpty() || address.isEmpty() || problem.isEmpty()) {
            actionTarget.setFill(Color.FIREBRICK);
            actionTarget.setText("Please fill all the fields.");
            return;
        }

        // Modified query without 'status' and 'submitted_by'
        String query = "INSERT INTO service_requests (name, address, problem_description, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";

        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            LOGGER.info("Executing query: " + query);
            LOGGER.info("Binding values: name = " + name + ", address = " + address + ", problem = " + problem);

            statement.setString(1, name);
            statement.setString(2, address);
            statement.setString(3, problem);

            int rows = statement.executeUpdate();
            if (rows > 0) {
                actionTarget.setFill(Color.GREEN);
                actionTarget.setText("Request submitted successfully!");
                clearFields();
                navigateToDashboard(name, address, problem);
            } else {
                actionTarget.setFill(Color.FIREBRICK);
                actionTarget.setText("Failed to submit the request.");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Error during request submission: " + e.getMessage(), e);
            actionTarget.setFill(Color.FIREBRICK);
            actionTarget.setText("An error occurred while submitting the request.");
        }
    }

    private void navigateToDashboard(String name, String address, String problem) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
            Parent root = loader.load();

            // Get the controller and set user data
            DashboardController controller = loader.getController();
            controller.setUserData(name, address, problem);

            // Load the dashboard in the same stage
            Stage stage = (Stage) nameField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Dashboard");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error navigating to the dashboard", e);
            actionTarget.setFill(Color.FIREBRICK);
            actionTarget.setText("Failed to navigate to the dashboard.");
        }
    }

    private void clearFields() {
        nameField.clear();
        addressField.clear();
        problemField.clear();
    }

    @FXML
    public void onLoginButtonClick(ActionEvent actionEvent) {
        try {
            Main.showLoginForm();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error navigating to the login form", e);
            actionTarget.setFill(Color.FIREBRICK);
            actionTarget.setText("Failed to navigate to the login form.");
        }
    }
}

