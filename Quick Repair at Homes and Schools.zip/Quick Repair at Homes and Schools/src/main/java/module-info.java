module com.example.quickrepairathomesandschools {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.quickrepairathomesandschools to javafx.fxml;
    exports com.example.quickrepairathomesandschools;
}